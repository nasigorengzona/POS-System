﻿using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;

namespace FinalProjectSE
{

    public partial class ProductForm : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);
        int id;
        public void refresh() //REFRESH PAGE SEHABIS REMOVE, ADD, DAN EDIT 
        {
            if (Server.State != ConnectionState.Closed) Server.Close(); //JIKA KONEKSI GAGAL TUTUP 

            SqlDataAdapter da = new SqlDataAdapter("Select * from Product ", Server);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];

                ListViewItem itm = new ListViewItem(dr["idProd"].ToString());
                itm.SubItems.Add(dr["nameProd"].ToString());
                itm.SubItems.Add(dr["priceProdBuy"].ToString());
                itm.SubItems.Add(dr["cateProd"].ToString());
                itm.SubItems.Add(dr["unitProd"].ToString());
                itm.SubItems.Add(dr["markupPriceProd"].ToString());
                lvProd.Items.Add(itm);
            }
        }
        public ProductForm()
        {
            InitializeComponent();
            refresh();
        }

        //TAMBAH PRODUCT KE DALAM DATABASE  
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //CEK APAKAH TEXTBOX KOSONG , JIKA IYA KELUAR MESSAGEBOX
                if (tbProdName.Text == "" || tbProdPrice.Text == "") MessageBox.Show("All Fields Are Compulsory ! ! !");

                //JIKA TIDAK, MAKA AKAN DILANJUTKAN 
                else
                {
                    Server.Open();
                    SqlCommand cmd = new SqlCommand("Insert into Product (nameProd, priceProdBuy, qtyProd, unitProd, cateProd, orderedTimesProd, priceProdSell, markupPriceProd) VALUES ( '" + tbProdName.Text + "' , '" + tbProdPrice.Text + "' , '" + 0 + "' , '" + cbProdUnit.Text + "' , '" + cbProdCate.Text + "' , '" + 0 + "' , '" + Convert.ToInt32(tbProdPrice.Text) + (Convert.ToInt32(tbProdPrice.Text) * (Convert.ToInt32(tbProfit.Text) * 0.01)) + "' , '"+ tbProfit.Text +"' )", Server);
                    cmd.ExecuteNonQuery(); 
                    MessageBox.Show("Data has been saved");
                    Server.Close();
                    cmd.Dispose();
                    //TEXTBOX DISET KEMBALI MENJADI ""
                    tbProdName.Text = "";
                    tbProdPrice.Text = "";
                    cbProdCate.Text = "";
                    cbProdUnit.Text = "";
                    tbProfit.Text = "";
                    //REFRESH LISTVIEW
                    lvProd.Items.Clear();
                    refresh();
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //KETIKA TEKAN ITEM DI LISTVIEW
        private void lvProd_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (lvProd.SelectedItems.Count > 0)
            {
                ListViewItem item = lvProd.SelectedItems[0];
                id = Convert.ToInt32(item.SubItems[0].Text);
                tbProdName.Text = item.SubItems[1].Text;
                tbProdPrice.Text = item.SubItems[2].Text;
                cbProdCate.Text = item.SubItems[3].Text;
                cbProdUnit.Text = item.SubItems[4].Text;
                tbProfit.Text = item.SubItems[5].Text;
            }
        }

        //EDIT DATA PRODUCT
        private void btnEdit_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (lvProd.SelectedItems.Count == 0) MessageBox.Show("SELECT ITEM FIRST IN TABLE ! ");
                else
                {
                    Server.Open();
                    SqlCommand cmd = new SqlCommand("Update Product Set nameProd = '" + tbProdName.Text + "' , priceProdBuy = '" + tbProdPrice.Text + "' , unitProd = '" + cbProdUnit.Text + "' , cateProd = '" + cbProdCate.Text + "' , markupPriceProd = '" + tbProfit.Text + "' , priceProdSell = '" + (Convert.ToInt32(tbProdPrice.Text) + Convert.ToInt32(tbProdPrice.Text) * (Convert.ToInt32(tbProfit.Text) * 0.01)) + "'  where idProd = '" + id + "'", Server);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data has been saved");
                    Server.Close();
                    cmd.Dispose();
                    //TEXTBOX DISET KEMBALI MENJADI ""
                    tbProdName.Text = "";
                    tbProdPrice.Text = "";
                    cbProdCate.Text = "";
                    cbProdUnit.Text = "";
                    tbProfit.Text = "";
                    //REFRESH LISTVIEW
                    lvProd.Items.Clear();
                    refresh();
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //DELETE PRODUCT
        private void btnDelete_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (lvProd.SelectedItems.Count < 1) MessageBox.Show("Select First");
                else
                {
                    Server.Open();
                    //CEK APAKAH PRODUCT SUDAH PERNAH DIBELI
                    SqlCommand cmdCheckId1 = new SqlCommand("Select count(*) from Purchase where idProd = '" + id + "'", Server);
                    int count1 = Convert.ToInt32(cmdCheckId1.ExecuteScalar());
                    cmdCheckId1.Dispose();
                    //CEK APAKAH PRODUCT SUDAH PERNAH DIJUAL
                    SqlCommand cmdCheckId2 = new SqlCommand("Select count(*) from Sales where idProd = '" + id + "'", Server);
                    int count2 = Convert.ToInt32(cmdCheckId2.ExecuteScalar());
                    cmdCheckId2.Dispose();
                    Server.Close();

                    if (count1 > 0 && count2 > 0)
                    {
                        MessageBox.Show("Sorry, cannot delete this data (As this data has record on Sales & Purchase)");
                        //TEXTBOX DISET KEMBALI MENJADI ""
                        cbProdCate.SelectedIndex = -1;
                        cbProdUnit.SelectedIndex = -1;
                        tbProdName.Text = "";
                        tbProdPrice.Text = "";
                        tbProfit.Text = "";
                    }
                    else
                    {
                        //TEXTBOX DISET KEMBALI MENJADI ""
                        cbProdCate.SelectedIndex = -1;
                        cbProdUnit.SelectedIndex = -1;
                        tbProdName.Text = "";
                        tbProdPrice.Text = "";
                        tbProfit.Text = "";

                        //AKSES DATABASE 
                        Server.Open();
                        SqlCommand cmd = new SqlCommand("Delete Product where idProd = '" + id + "'", Server);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data has been deleted");
                        Server.Close();
                        cmd.Dispose();

                        //REFRESH LISTVIEW
                        lvProd.Items.Clear();
                        refresh();
                    }
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //FILTER PRODUCT
        private void tbSearch_TextChanged(object sender, System.EventArgs e)
        {
            List<ListViewItem> allItems = new List<ListViewItem>();
            allItems.Clear();
            allItems.AddRange(lvProd.Items.Cast<ListViewItem>());
            lvProd.Items.Clear();
            if (tbSearch.Text == "") refresh();
            else
            {
                var list = allItems.Cast<ListViewItem>()
                       .Where(x => x.SubItems
                                     .Cast<ListViewItem.ListViewSubItem>()
                                     .Any(y => y.Text.Contains(tbSearch.Text)))
                       .ToArray();
                lvProd.Items.AddRange(list);
            }
        }

        //KEMBALI KE HALAMAN MAIN MENU
        private void btnBack_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form2 tobeOpen = new Form2();
            tobeOpen.Show();
        }

    }
}
