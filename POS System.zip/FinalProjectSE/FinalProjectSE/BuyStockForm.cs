﻿using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;

namespace FinalProjectSE
{
    public partial class BuyStockForm : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);
        int priceProduct;
        int idProduct;
        int idSupplier;
        //LOAD NAMA SUPPLIER DARI DATABASE KE COMBOBOX
        private void loadCbSupp ()
        {
            Server.Open();
            SqlCommand cmd = new SqlCommand("Select idSupp , nameSupp from Supplier", Server);
            SqlDataReader reader = cmd.ExecuteReader();
            cbSupp.Items.Clear();
            while (reader.Read())
            {
                string cbItemsSupp = reader[0].ToString() + " " + reader[1].ToString() ;
                cbSupp.Items.Add(cbItemsSupp);
            }
            cmd.Dispose();
            Server.Close();
        }

        //LOAD NAMA PRODUCT DARI DATABASE KE COMBOBOX
        private void loadCbProd ()
        {
            Server.Open();
            SqlCommand cmd = new SqlCommand("Select idProd , nameProd from Product", Server);
            SqlDataReader reader = cmd.ExecuteReader();
            cbProd.Items.Clear();
            while (reader.Read())
            {
                string cbItemsProd = reader[0].ToString() + " " + reader[1].ToString();
                cbProd.Items.Add(cbItemsProd);
            }
            cmd.Dispose();
            Server.Close();
        }

        //REFRESH PAGE SEHABIS BUY
        public void refresh()  
        {
            Server.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Purchase ", Server);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];

                ListViewItem itm = new ListViewItem(dr["idPurchase"].ToString());
                
                //AMBIL NAMA SUPPLIER DARI ID SUPPLIER
                int idSupplier = Convert.ToInt32(dr["idSupp"].ToString());
                SqlCommand cmdIdSupp = new SqlCommand("Select nameSupp from Supplier where idSupp = '" + idSupplier + "'", Server);
                var nameSupplier = cmdIdSupp.ExecuteScalar();
                cmdIdSupp.Dispose();
                itm.SubItems.Add(nameSupplier.ToString());

                //AMBIL NAMA PRODUCT DARI ID PRODUCT
                int idProduct = Convert.ToInt32(dr["idProd"].ToString());
                SqlCommand cmdIdProd = new SqlCommand("Select nameProd from Product where idProd = '" + idProduct + "'", Server);
                var nameProduct = cmdIdProd.ExecuteScalar();
                cmdIdProd.Dispose();
                itm.SubItems.Add(nameProduct.ToString());

                itm.SubItems.Add(dr["qtyProdPurchase"].ToString());
                itm.SubItems.Add(dr["totalPricePurchase"].ToString());
                itm.SubItems.Add(dr["datePurchase"].ToString());
                lvPurchase.Items.Add(itm);
            }
            Server.Close();
        }

        //GANTI TOTAL HARGA 
        private void totalPriceCount ()
        {
            try
            {
                //AMBIL ID PRODUCT DENGAN SPLIT TEXT DARI VALUE COMBOBOX
                idProduct = Convert.ToInt32(cbProd.Text.Split(' ')[0]);

                //AMBIL HARGA PRODUCT DARI DATABASE
                Server.Open();
                SqlCommand cmdPriceProd = new SqlCommand("Select priceProdBuy from Product where idProd = '"+ idProduct +"'", Server);
                priceProduct = Convert.ToInt32(cmdPriceProd.ExecuteScalar());
                Server.Close();
                cmdPriceProd.Dispose();

                lblTotalPricePurchase.Text = (nudQty.Value * priceProduct).ToString();
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        public BuyStockForm()
        {
            InitializeComponent();
            loadCbSupp();
            loadCbProd();
            refresh();
        }

        //JIKA VALUE DI NUD BERGANTI MAKA LABEL TOTAL JUGA GANTI 
        private void nudQty_ValueChanged(object sender, System.EventArgs e)
        {
            if (cbProd.SelectedIndex != -1)
            {
                totalPriceCount();
            } 

        }

        //JIKA MENGGANTI PRODUK NAMUN TOTAL BARANG SUDAH DIHITUNG 
        private void cbProd_TextChanged(object sender, System.EventArgs e)
        {
            if (lblTotalPricePurchase.Text != "-") totalPriceCount();
        }

        //UNTUK MEMBELI BARANG (MENAMBAH STOCK)
        private void btnBuy_Click(object sender, EventArgs e)
        {
            try {
                //CEK APAKAH TEXTBOX KOSONG , JIKA IYA KELUAR MESSAGEBOX
                if (cbSupp.SelectedIndex == -1 || cbProd.SelectedIndex == -1 || nudQty.Value == 0) MessageBox.Show("All Fields Are Compulsory ! ! !");

                //JIKA TIDAK, MAKA AKAN DILANJUTKAN 
                else
                {
                    //AMBIL ID SUPPLIER
                    idSupplier = Convert.ToInt32(cbSupp.Text.Split(' ')[0]);
                    //MASUKAN DATA PURCHASE KE DATABASE
                    Server.Open();
                    SqlCommand cmdUpdatePurchase = new SqlCommand("Insert into Purchase (idSupp, idProd, qtyProdPurchase, totalPricePurchase, datePurchase) VALUES ( '" + idSupplier + "' , '" + idProduct + "' , '" + (int)nudQty.Value + "' , '" + Convert.ToInt32(lblTotalPricePurchase.Text) + "' , '" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "' )", Server);
                    cmdUpdatePurchase.ExecuteNonQuery();
                    MessageBox.Show("Data has been saved");
                    cmdUpdatePurchase.Dispose();

                    //TAMBAH STOCK
                    SqlCommand cmdUpdateStock = new SqlCommand("Update Product Set qtyProd = qtyProd + '" + Convert.ToInt32(nudQty.Value) + "' where idProd = '" + idProduct + "' ", Server);
                    cmdUpdateStock.ExecuteNonQuery();
                    cmdUpdateStock.Dispose();
                    Server.Close();

                    //COMBOBOX, NUMERICUPDOWN DAN LABEL DISET KEMBALI MENJADI SEMULA
                    lblTotalPricePurchase.Text = "-";
                    cbSupp.SelectedIndex = -1;
                    cbProd.SelectedIndex = -1;
                    nudQty.Value = Convert.ToDecimal(0);
                    //REFRESH LISTVIEW
                    lvPurchase.Items.Clear();
                    refresh();
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //FILTER DATA PEMBELIAN
        private void tbSearch_TextChanged(object sender, System.EventArgs e)
        {
            List<ListViewItem> allItems = new List<ListViewItem>();
            allItems.Clear();
            allItems.AddRange(lvPurchase.Items.Cast<ListViewItem>());
            lvPurchase.Items.Clear();
            if (tbSearch.Text == "") refresh();
            else
            {
                var list = allItems.Cast<ListViewItem>()
                       .Where(x => x.SubItems
                                     .Cast<ListViewItem.ListViewSubItem>()
                                     .Any(y => y.Text.Contains(tbSearch.Text)))
                       .ToArray();
                lvPurchase.Items.AddRange(list);
            }   
        }

        //KEMBALI KE FORM STOCK
        private void btnBack_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            StockForm tobeOpen = new StockForm();
            tobeOpen.Show();
        }

    }
}
