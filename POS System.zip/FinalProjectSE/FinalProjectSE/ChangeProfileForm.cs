﻿using System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;

namespace FinalProjectSE
{
    public partial class ChangeProfileForm : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);
        public int id = Form1.idAdmin;

        private void loadAdminData()
        {
            Server.Open();
            //LOAD NAMA
            SqlCommand cmdName = new SqlCommand("Select nameAdmin from Admin where idAdmin = '" + id + "'", Server);
            tbAdminName.Text = cmdName.ExecuteScalar().ToString();
            cmdName.Dispose();
            //LOAD PASS
            SqlCommand cmdPass = new SqlCommand("Select passAdmin from Admin where idAdmin = '" + id + "'", Server);
            tbAdminPass.Text = cmdPass.ExecuteScalar().ToString();
            cmdPass.Dispose();
            //LOAD USERNAME
            SqlCommand cmdUsername = new SqlCommand("Select usernameAdmin from Admin where idAdmin = '" + id + "'", Server);
            tbAdminUsername.Text = cmdUsername.ExecuteScalar().ToString();
            cmdUsername.Dispose();
            Server.Close();
        }

        public ChangeProfileForm()
        {
            InitializeComponent();
            loadAdminData();
        }

        //UNTUK CEK APAKAH USERNAME SUDAH DIGUNAKAN
        private bool checkUsername()
        {
            Server.Open();
            SqlCommand cmd = new SqlCommand("Select Count(*) from Admin where usernameAdmin = '"+tbAdminUsername.Text+"'", Server);
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            cmd.Dispose();
            Server.Close();
            if (count <= 1) return true;
            else return false;
        }

        //EDIT NAMA, USERNAME DAN PASS DATA ADMIN
        private void btnEdit_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (tbAdminName.Text == "" || tbAdminPass.Text == "" || tbAdminUsername.Text == "") MessageBox.Show("ALL FIELDS ARE MANDATORY !!!");
                else
                {
                    if (checkUsername())
                    {
                        Server.Open();
                        SqlCommand cmd = new SqlCommand("Update Admin Set nameAdmin = '" + tbAdminName.Text + "' , passAdmin = '" + tbAdminPass.Text + "' , usernameAdmin = '" + tbAdminUsername.Text + "' where idAdmin = '" + id + "'", Server);
                        cmd.ExecuteNonQuery();
                        Server.Close();
                        cmd.Dispose();
                        //TEXTBOX DISET KEMBALI MENJADI ""
                        tbAdminName.Text = "";
                        tbAdminPass.Text = "";
                        tbAdminUsername.Text = "";

                        //TAMPILKAN PESAN 
                        MessageBox.Show("PROFILE CHANGED");

                        //KEMBALI KE MAIN MENU
                        this.Hide();
                        Form2 tobeOpen = new Form2();
                        tobeOpen.Show();
                    }
                    else MessageBox.Show("Someone already has that username please change"); tbAdminUsername.Text = "";
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //KEMBALI KE MAIN MENU
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 tobeOpen = new Form2();
            tobeOpen.Show();
        }


    }
}
