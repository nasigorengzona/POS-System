﻿namespace FinalProjectSE
{
    partial class SellStockForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSearch = new System.Windows.Forms.Button();
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lvSales = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTotalPriceSale = new System.Windows.Forms.Label();
            this.nudQty = new System.Windows.Forms.NumericUpDown();
            this.cbProd = new System.Windows.Forms.ComboBox();
            this.cbCust = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblCustAdd = new System.Windows.Forms.Label();
            this.lblCustEmail = new System.Windows.Forms.Label();
            this.btnSell = new System.Windows.Forms.Button();
            this.lblCustTelp = new System.Windows.Forms.Label();
            this.lblCustName = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQty)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(593, 41);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(69, 20);
            this.btnSearch.TabIndex = 19;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // tbSearch
            // 
            this.tbSearch.Location = new System.Drawing.Point(224, 41);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(363, 20);
            this.tbSearch.TabIndex = 18;
            this.tbSearch.TextChanged += new System.EventHandler(this.tbSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(366, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "LIST SALES";
            // 
            // lvSales
            // 
            this.lvSales.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.lvSales.FullRowSelect = true;
            this.lvSales.HideSelection = false;
            this.lvSales.Location = new System.Drawing.Point(224, 67);
            this.lvSales.MultiSelect = false;
            this.lvSales.Name = "lvSales";
            this.lvSales.Size = new System.Drawing.Size(438, 254);
            this.lvSales.TabIndex = 16;
            this.lvSales.UseCompatibleStateImageBehavior = false;
            this.lvSales.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 37;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "CUSTOMER";
            this.columnHeader2.Width = 77;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "PRODUCT";
            this.columnHeader3.Width = 75;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "QTY";
            this.columnHeader4.Width = 52;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "TOTAL";
            this.columnHeader5.Width = 100;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "DATE";
            this.columnHeader6.Width = 94;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblTotalPriceSale);
            this.panel1.Controls.Add(this.nudQty);
            this.panel1.Controls.Add(this.cbProd);
            this.panel1.Controls.Add(this.cbCust);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.lblCustAdd);
            this.panel1.Controls.Add(this.lblCustEmail);
            this.panel1.Controls.Add(this.btnSell);
            this.panel1.Controls.Add(this.lblCustTelp);
            this.panel1.Controls.Add(this.lblCustName);
            this.panel1.Location = new System.Drawing.Point(2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(216, 333);
            this.panel1.TabIndex = 20;
            // 
            // lblTotalPriceSale
            // 
            this.lblTotalPriceSale.AutoSize = true;
            this.lblTotalPriceSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPriceSale.Location = new System.Drawing.Point(130, 197);
            this.lblTotalPriceSale.Name = "lblTotalPriceSale";
            this.lblTotalPriceSale.Size = new System.Drawing.Size(13, 17);
            this.lblTotalPriceSale.TabIndex = 33;
            this.lblTotalPriceSale.Text = "-";
            // 
            // nudQty
            // 
            this.nudQty.Location = new System.Drawing.Point(84, 147);
            this.nudQty.Name = "nudQty";
            this.nudQty.Size = new System.Drawing.Size(121, 20);
            this.nudQty.TabIndex = 32;
            this.nudQty.ValueChanged += new System.EventHandler(this.nudQty_ValueChanged);
            // 
            // cbProd
            // 
            this.cbProd.FormattingEnabled = true;
            this.cbProd.Location = new System.Drawing.Point(84, 97);
            this.cbProd.Name = "cbProd";
            this.cbProd.Size = new System.Drawing.Size(121, 21);
            this.cbProd.TabIndex = 31;
            this.cbProd.TextChanged += new System.EventHandler(this.cbProd_TextChanged);
            // 
            // cbCust
            // 
            this.cbCust.FormattingEnabled = true;
            this.cbCust.Location = new System.Drawing.Point(84, 48);
            this.cbCust.Name = "cbCust";
            this.cbCust.Size = new System.Drawing.Size(121, 21);
            this.cbCust.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "SALES DETAIL";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(14, 297);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(191, 24);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblCustAdd
            // 
            this.lblCustAdd.AutoSize = true;
            this.lblCustAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustAdd.Location = new System.Drawing.Point(14, 197);
            this.lblCustAdd.Name = "lblCustAdd";
            this.lblCustAdd.Size = new System.Drawing.Size(54, 17);
            this.lblCustAdd.TabIndex = 28;
            this.lblCustAdd.Text = "TOTAL";
            // 
            // lblCustEmail
            // 
            this.lblCustEmail.AutoSize = true;
            this.lblCustEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustEmail.Location = new System.Drawing.Point(14, 147);
            this.lblCustEmail.Name = "lblCustEmail";
            this.lblCustEmail.Size = new System.Drawing.Size(30, 17);
            this.lblCustEmail.TabIndex = 26;
            this.lblCustEmail.Text = "Qty";
            // 
            // btnSell
            // 
            this.btnSell.Location = new System.Drawing.Point(14, 244);
            this.btnSell.Name = "btnSell";
            this.btnSell.Size = new System.Drawing.Size(191, 37);
            this.btnSell.TabIndex = 7;
            this.btnSell.Text = "SELL";
            this.btnSell.UseVisualStyleBackColor = true;
            this.btnSell.Click += new System.EventHandler(this.btnSell_Click);
            // 
            // lblCustTelp
            // 
            this.lblCustTelp.AutoSize = true;
            this.lblCustTelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustTelp.Location = new System.Drawing.Point(14, 98);
            this.lblCustTelp.Name = "lblCustTelp";
            this.lblCustTelp.Size = new System.Drawing.Size(57, 17);
            this.lblCustTelp.TabIndex = 24;
            this.lblCustTelp.Text = "Product";
            // 
            // lblCustName
            // 
            this.lblCustName.AutoSize = true;
            this.lblCustName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustName.Location = new System.Drawing.Point(14, 49);
            this.lblCustName.Name = "lblCustName";
            this.lblCustName.Size = new System.Drawing.Size(68, 17);
            this.lblCustName.TabIndex = 22;
            this.lblCustName.Text = "Customer";
            // 
            // SellStockForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 332);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.tbSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lvSales);
            this.Name = "SellStockForm";
            this.Text = "SellStock";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lvSales;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTotalPriceSale;
        private System.Windows.Forms.NumericUpDown nudQty;
        private System.Windows.Forms.ComboBox cbProd;
        private System.Windows.Forms.ComboBox cbCust;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblCustAdd;
        private System.Windows.Forms.Label lblCustEmail;
        private System.Windows.Forms.Button btnSell;
        private System.Windows.Forms.Label lblCustTelp;
        private System.Windows.Forms.Label lblCustName;
    }
}