﻿namespace FinalProjectSE
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStock = new System.Windows.Forms.Button();
            this.btnProd = new System.Windows.Forms.Button();
            this.btnCust = new System.Windows.Forms.Button();
            this.btnSupp = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnChangeProf = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStock
            // 
            this.btnStock.Location = new System.Drawing.Point(12, 12);
            this.btnStock.Name = "btnStock";
            this.btnStock.Size = new System.Drawing.Size(84, 69);
            this.btnStock.TabIndex = 0;
            this.btnStock.Text = "STOCK";
            this.btnStock.UseVisualStyleBackColor = true;
            this.btnStock.Click += new System.EventHandler(this.btnStock_Click);
            // 
            // btnProd
            // 
            this.btnProd.Location = new System.Drawing.Point(12, 116);
            this.btnProd.Name = "btnProd";
            this.btnProd.Size = new System.Drawing.Size(84, 69);
            this.btnProd.TabIndex = 1;
            this.btnProd.Text = "PRODUCT";
            this.btnProd.UseVisualStyleBackColor = true;
            this.btnProd.Click += new System.EventHandler(this.btnProd_Click);
            // 
            // btnCust
            // 
            this.btnCust.Location = new System.Drawing.Point(12, 221);
            this.btnCust.Name = "btnCust";
            this.btnCust.Size = new System.Drawing.Size(84, 69);
            this.btnCust.TabIndex = 2;
            this.btnCust.Text = "CUSTOMER";
            this.btnCust.UseVisualStyleBackColor = true;
            this.btnCust.Click += new System.EventHandler(this.btnCust_Click);
            // 
            // btnSupp
            // 
            this.btnSupp.Location = new System.Drawing.Point(147, 12);
            this.btnSupp.Name = "btnSupp";
            this.btnSupp.Size = new System.Drawing.Size(84, 69);
            this.btnSupp.TabIndex = 3;
            this.btnSupp.Text = "SUPPLIER";
            this.btnSupp.UseVisualStyleBackColor = true;
            this.btnSupp.Click += new System.EventHandler(this.btnSupp_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(147, 116);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(84, 174);
            this.btnLogOut.TabIndex = 4;
            this.btnLogOut.Text = "LOG OUT";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(273, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 43);
            this.label1.TabIndex = 5;
            this.label1.Text = "HELLO, WELCOME BACK";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblName
            // 
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(273, 70);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(124, 43);
            this.lblName.TabIndex = 6;
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnChangeProf
            // 
            this.btnChangeProf.Location = new System.Drawing.Point(276, 257);
            this.btnChangeProf.Name = "btnChangeProf";
            this.btnChangeProf.Size = new System.Drawing.Size(121, 33);
            this.btnChangeProf.TabIndex = 7;
            this.btnChangeProf.Text = "Change Profile";
            this.btnChangeProf.UseVisualStyleBackColor = true;
            this.btnChangeProf.Click += new System.EventHandler(this.btnChangeProf_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 302);
            this.Controls.Add(this.btnChangeProf);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSupp);
            this.Controls.Add(this.btnCust);
            this.Controls.Add(this.btnProd);
            this.Controls.Add(this.btnStock);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnStock;
        private System.Windows.Forms.Button btnProd;
        private System.Windows.Forms.Button btnCust;
        private System.Windows.Forms.Button btnSupp;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnChangeProf;
    }
}