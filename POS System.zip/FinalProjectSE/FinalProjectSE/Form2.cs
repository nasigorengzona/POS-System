﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
namespace FinalProjectSE
{
    public partial class Form2 : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);
        public int idAdminForm2 = Form1.idAdmin;
        string nameAdmin;
        public string getAdminName(int id)
        {
            Server.Open();
            SqlCommand cmd = new SqlCommand("Select nameAdmin from Admin where idAdmin = '"+ id +"'", Server);
            nameAdmin = cmd.ExecuteScalar().ToString();
            cmd.Dispose();
            Server.Close();
            return nameAdmin;
        }

        public Form2()
        {
            InitializeComponent();
            lblName.Text = getAdminName(idAdminForm2);
        }

        //BUKA FORM CUSTOMER 
        private void btnCust_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerForm tobeOpen = new CustomerForm();
            tobeOpen.Show();
        }

        private void btnProd_Click(object sender, EventArgs e)
        {
            this.Hide();
            ProductForm tobeOpen = new ProductForm();
            tobeOpen.Show();
        }

        private void btnSupp_Click(object sender, EventArgs e)
        {
            this.Hide();
            SupplierForm tobeOpen = new SupplierForm();
            tobeOpen.Show();
        }

        private void btnStock_Click(object sender, EventArgs e)
        {
            this.Hide();
            StockForm tobeOpen = new StockForm();
            tobeOpen.Show();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 tobeOpen = new Form1();
            tobeOpen.Show();
        }

        private void btnChangeProf_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChangeProfileForm tobeOpen = new ChangeProfileForm();
            tobeOpen.Show();
        }
    }
}
