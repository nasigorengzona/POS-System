﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace FinalProjectSE
{
    class DBConn
    {
        public static string ConnectionString = "Data Source = DESKTOP-PT8RDOM; Initial Catalog = ProgStock ; Integrated Security = SSPI";
    }
}
