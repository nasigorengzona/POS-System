﻿using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;

namespace FinalProjectSE
{
    public partial class CustomerForm : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);
        int id;

        public void  refresh() //REFRESH PAGE SEHABIS REMOVE, ADD, DAN EDIT 
        {
            if (Server.State != ConnectionState.Closed) Server.Close(); //JIKA KONEKSI GAGAL TUTUP 

            SqlDataAdapter da = new SqlDataAdapter("Select * from Customer ", Server);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];

                ListViewItem itm = new ListViewItem(dr["idCust"].ToString());
                itm.SubItems.Add(dr["nameCust"].ToString());
                itm.SubItems.Add(dr["telpCust"].ToString());
                itm.SubItems.Add(dr["emailCust"].ToString());
                itm.SubItems.Add(dr["addCust"].ToString());
                lvCust.Items.Add(itm);
            }
        }
        public CustomerForm()
        {
            InitializeComponent();
            refresh();
        }

        //TAMBAH CUSTOMER KE DALAM DATABASE 
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //CEK APAKAH TEXTBOX KOSONG , JIKA IYA KELUAR MESSAGEBOX
                if (tbCustAdd.Text == "" || tbCustEmail.Text == "" || tbCustName.Text == "" || tbCustTelp.Text == "") MessageBox.Show("All Fields Are Compulsory ! ! !");

                //JIKA TIDAK, MAKA AKAN DILANJUTKAN 
                else
                {
                    Server.Open();
                    SqlCommand cmd = new SqlCommand("Insert into Customer (nameCust, telpCust, emailCust, addCust) VALUES ( '" + tbCustName.Text + "' , '" + tbCustTelp.Text + "' , '" + tbCustEmail.Text + "' , '" + tbCustAdd.Text + "' )", Server);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data has been saved");
                    Server.Close();
                    cmd.Dispose();
                    //TEXTBOX DISET KEMBALI MENJADI ""
                    tbCustAdd.Text = "";
                    tbCustEmail.Text = "";
                    tbCustName.Text = "";
                    tbCustTelp.Text = "";
                    //REFRESH LISTVIEW
                    lvCust.Items.Clear();
                    refresh();
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //KETIKA TEKAN ITEM DI LISTVIEW
        private void lvCust_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (lvCust.SelectedItems.Count > 0)
            {
                ListViewItem item = lvCust.SelectedItems[0];
                id = Convert.ToInt32(item.SubItems[0].Text);
                tbCustName.Text = item.SubItems[1].Text;
                tbCustTelp.Text = item.SubItems[2].Text;
                tbCustEmail.Text = item.SubItems[3].Text;
                tbCustAdd.Text = item.SubItems[4].Text;
            }
        }

        //EDIT DATA CUSTOMER
        private void btnEdit_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (lvCust.SelectedItems.Count == 0) MessageBox.Show("SELECT ITEM FIRST IN TABLE ! ");
                else
                {
                    Server.Open();
                    SqlCommand cmd = new SqlCommand("Update Customer Set nameCust = '" + tbCustName.Text + "' , telpCust = '" + tbCustTelp.Text + "' , emailCust = '" + tbCustEmail.Text + "' , addCust = '"+ tbCustAdd.Text +"' where idCust = '"+ id +"'", Server);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data has been saved");
                    Server.Close();
                    cmd.Dispose();
                    //TEXTBOX DISET KEMBALI MENJADI ""
                    tbCustAdd.Text = "";
                    tbCustEmail.Text = "";
                    tbCustName.Text = "";
                    tbCustTelp.Text = "";
                    //REFRESH LISTVIEW
                    lvCust.Items.Clear();
                    refresh();
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //DELETE CUSTOMER 
        private void btnDelete_Click(object sender, System.EventArgs e)
        {
            try {
                if (lvCust.SelectedItems.Count < 1) MessageBox.Show("Select First");
                else {
                    Server.Open();
                    SqlCommand cmdCheckId = new SqlCommand("Select count(*) from Sales where idCust = '" + id + "'", Server);
                    int count = Convert.ToInt32(cmdCheckId.ExecuteScalar());
                    cmdCheckId.Dispose();
                    if (count > 0)
                    {
                        MessageBox.Show("Sorry, cannot delete this data (As this data has record on Sales)");
                        //TEXTBOX DISET KEMBALI MENJADI ""
                        tbCustAdd.Text = "";
                        tbCustEmail.Text = "";
                        tbCustName.Text = "";
                        tbCustTelp.Text = "";
                    }

                    else
                    {
                        //TEXTBOX DISET KEMBALI MENJADI ""
                        tbCustAdd.Text = "";
                        tbCustEmail.Text = "";
                        tbCustName.Text = "";
                        tbCustTelp.Text = "";

                        //AKSES DATABASE 
                        SqlCommand cmd = new SqlCommand("Delete Customer where idCust = '" + id + "'", Server);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data has been deleted");
                        Server.Close();
                        cmd.Dispose();
                        //REFRESH LISTVIEW
                        lvCust.Items.Clear();
                        refresh();
                    }

                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //FILTER CUSTOMER
        private void tbSearch_TextChanged(object sender, System.EventArgs e)
        {
            List<ListViewItem> allItems = new List<ListViewItem>();
            allItems.Clear();
            allItems.AddRange(lvCust.Items.Cast<ListViewItem>());
            lvCust.Items.Clear();
            if (tbSearch.Text == "") refresh();
            else
            {
                var list = allItems.Cast<ListViewItem>()
                       .Where(x => x.SubItems
                                     .Cast<ListViewItem.ListViewSubItem>()
                                     .Any(y => y.Text.Contains(tbSearch.Text)))
                       .ToArray();
                lvCust.Items.AddRange(list);
            }            
        }

        //KEMBALI KE HALAMAN MAIN MENU
        private void button1_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Form2 tobeOpen = new Form2();
            tobeOpen.Show(); 
        }

    }
}
