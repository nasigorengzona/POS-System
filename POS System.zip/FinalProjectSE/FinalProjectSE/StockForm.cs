﻿using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;

namespace FinalProjectSE
{
    public partial class StockForm : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);
        public void refresh() //REFRESH PAGE SEHABIS REMOVE, ADD, DAN EDIT 
        {
            if (Server.State != ConnectionState.Closed) Server.Close(); //JIKA KONEKSI GAGAL TUTUP 

            SqlDataAdapter da = new SqlDataAdapter("Select * from Product ", Server);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];

                ListViewItem itm = new ListViewItem(dr["idProd"].ToString());
                itm.SubItems.Add(dr["nameProd"].ToString());
                itm.SubItems.Add(dr["qtyProd"].ToString());
                itm.SubItems.Add(dr["unitProd"].ToString());
                itm.SubItems.Add(dr["cateProd"].ToString());
                lvCust.Items.Add(itm);
            }
        }
        public StockForm()
        {
            InitializeComponent();
            refresh();
        }


        //KEMBALI KE HALAMAN MAIN MENU
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 tobeOpen = new Form2();
            tobeOpen.Show();
        }

        //UNTUK KE PURCHASING FORM
        private void btnAddStock_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            BuyStockForm tobeOpen = new BuyStockForm();
            tobeOpen.Show();
        }

        //UNTUK KE SALES FORM
        private void btnSell_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            SellStockForm tobeOpen = new SellStockForm();
            tobeOpen.Show();
        }
    }
}
