﻿using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;

namespace FinalProjectSE
{
    public partial class SellStockForm : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);
        int priceProduct;
        int idProduct;
        int idCustomer;
        int qtyProduct;

        //LOAD NAMA CUSTOMER DARI DATABASE KE COMBOBOX
        private void loadCbCust ()
        {
            Server.Open();
            SqlCommand cmd = new SqlCommand("Select idCust , nameCust from Customer", Server);
            SqlDataReader reader = cmd.ExecuteReader();
            cbCust.Items.Clear();
            while (reader.Read())
            {
                string cbItemsCust= reader[0].ToString() + " " + reader[1].ToString();
                cbCust.Items.Add(cbItemsCust);
            }
            cmd.Dispose();
            Server.Close();
        }

        //LOAD NAMA PRODUCT DARI DATABASE KE COMBOBOX
        private void loadCbProd ()
        {
            Server.Open();
            SqlCommand cmd = new SqlCommand("Select idProd , nameProd from Product", Server);
            SqlDataReader reader = cmd.ExecuteReader();
            cbProd.Items.Clear();
            while (reader.Read())
            {
                string cbItemsProd = reader[0].ToString() + " " + reader[1].ToString();
                cbProd.Items.Add(cbItemsProd);
            }
            cmd.Dispose();
            Server.Close();
        }

        //REFRESH PAGE SEHABIS SELL
        public void refresh ()
        {
            Server.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Sales ", Server);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];

                ListViewItem itm = new ListViewItem(dr["idSales"].ToString());

                //AMBIL NAMA CUSTOMER DARI ID CUSTOMER
                int idCustomer = Convert.ToInt32(dr["idCust"].ToString());
                SqlCommand cmdIdCust = new SqlCommand("Select nameCust from Customer where idCust = '" + idCustomer + "'", Server);
                var nameCustomer = cmdIdCust.ExecuteScalar();
                cmdIdCust.Dispose();
                itm.SubItems.Add(nameCustomer.ToString());

                //AMBIL NAMA PRODUCT DARI ID PRODUCT
                int idProduct = Convert.ToInt32(dr["idProd"].ToString());
                SqlCommand cmdIdProd = new SqlCommand("Select nameProd from Product where idProd = '" + idProduct + "'", Server);
                var nameProduct = cmdIdProd.ExecuteScalar();
                cmdIdProd.Dispose();
                itm.SubItems.Add(nameProduct.ToString());

                itm.SubItems.Add(dr["qtyProdSales"].ToString());
                itm.SubItems.Add(dr["totalPriceSales"].ToString());
                itm.SubItems.Add(dr["dateSales"].ToString());
                lvSales.Items.Add(itm);
            }
            Server.Close();
        }

        //GANTI TOTAL HARGA 
        private void totalPriceCount ()
        {
            try
            {
                //AMBIL HARGA PRODUCT DARI DATABASE
                Server.Open();
                SqlCommand cmdPriceProd = new SqlCommand("Select priceProdSell from Product where idProd = '" + idProduct + "'", Server);
                priceProduct = Convert.ToInt32(cmdPriceProd.ExecuteScalar());
                Server.Close();
                cmdPriceProd.Dispose();

                lblTotalPriceSale.Text = (nudQty.Value * priceProduct).ToString();
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //CEK STOCK 
        private void checkQtyProduct()
        {
            try
            {
                Server.Open();
                //AMBIL ID PRODUCT DENGAN SPLIT TEXT DARI VALUE COMBOBOX
                idProduct = Convert.ToInt32(cbProd.Text.Split(' ')[0]);

                SqlCommand cmdCheckQtyProd = new SqlCommand("Select qtyProd from Product where idProd = '" + idProduct + "'", Server);
                qtyProduct = Convert.ToInt32(cmdCheckQtyProd.ExecuteScalar());
                cmdCheckQtyProd.Dispose();
                Server.Close();
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        public SellStockForm()
        {
            InitializeComponent();
            loadCbCust();
            loadCbProd();
            refresh();
        }

        //JIKA VALUE DI NUD BERGANTI MAKA LABEL TOTAL JUGA GANTI 
        private void nudQty_ValueChanged(object sender, System.EventArgs e)
        {
            if (cbProd.SelectedIndex != -1)
            {
                checkQtyProduct();
                if (qtyProduct > nudQty.Value) totalPriceCount();
                else
                {
                    MessageBox.Show("Product Quantity is not enough ! ! ! Stock Only " + qtyProduct.ToString());
                    nudQty.Value = 0;

                }
            }
        }

        //JIKA MENGGANTI PRODUK NAMUN TOTAL BARANG SUDAH DIHITUNG 
        private void cbProd_TextChanged(object sender, System.EventArgs e)
        {
            if (lblTotalPriceSale.Text != "-") checkQtyProduct(); if(qtyProduct > nudQty.Value) totalPriceCount();
        }

        //UNTUK MENJUAL BARANG (MENGURANGI STOCK)
        private void btnSell_Click(object sender, System.EventArgs e)
        {
            try
            {
                //CEK APAKAH TEXTBOX KOSONG , JIKA IYA KELUAR MESSAGEBOX
                if (cbCust.SelectedIndex == -1 || cbProd.SelectedIndex == -1 || nudQty.Value == 0) MessageBox.Show("All Fields Are Compulsory ! ! !");

                //JIKA TIDAK, MAKA AKAN DILANJUTKAN 
                else
                {
                    //AMBIL ID SUPPLIER
                    idCustomer = Convert.ToInt32(cbCust.Text.Split(' ')[0]);
                    //MASUKAN DATA SALES KE DATABASE
                    Server.Open();
                    SqlCommand cmdUpdateSales = new SqlCommand("Insert into Sales (idCust, idProd, qtyProdSales, totalPriceSales, dateSales) VALUES ( '" + idCustomer + "' , '" + idProduct + "' , '" + (int)nudQty.Value + "' , '" + Convert.ToInt32(lblTotalPriceSale.Text) + "' , '" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "' )", Server);
                    cmdUpdateSales.ExecuteNonQuery();
                    cmdUpdateSales.Dispose();
                    MessageBox.Show("Data has been saved");

                    //KURANG STOCK DAN MENAMBAH ORDERED TIMES
                    SqlCommand cmdUpdateStock = new SqlCommand("Update Product Set qtyProd = qtyProd - '" + Convert.ToInt32(nudQty.Value) + "', orderedTimesProd = orderedTimesProd + 1  where idProd = '" + idProduct + "' ", Server);
                    cmdUpdateStock.ExecuteNonQuery();
                    cmdUpdateStock.Dispose();
                    Server.Close();
                    
                    //COMBOBOX, NUMERICUPDOWN DAN LABEL DISET KEMBALI MENJADI SEMULA
                    nudQty.Value = Convert.ToDecimal(0);
                    lblTotalPriceSale.Text = "-";                    
                    cbCust.SelectedIndex = -1;
                    cbProd.SelectedIndex = -1;
                    
                    //REFRESH LISTVIEW
                    lvSales.Items.Clear();
                    refresh();
                }
            }
            //CEK APAKAH ADA ERROR DAN TAMPILKAN PESAN ERROR 
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //JIKA KONEKSI GAGAL TUTUP 
            if (Server.State != ConnectionState.Closed) Server.Close();
        }

        //FILTER DATA PENJUALAN
        private void tbSearch_TextChanged(object sender, System.EventArgs e)
        {
            List<ListViewItem> allItems = new List<ListViewItem>();
            allItems.Clear();
            allItems.AddRange(lvSales.Items.Cast<ListViewItem>());
            lvSales.Items.Clear();
            if (tbSearch.Text == "") refresh();
            else
            {
                var list = allItems.Cast<ListViewItem>()
                       .Where(x => x.SubItems
                                     .Cast<ListViewItem.ListViewSubItem>()
                                     .Any(y => y.Text.Contains(tbSearch.Text)))
                       .ToArray();
                lvSales.Items.AddRange(list);
            }
        }

        //KEMBALI KE FORM STOCK
        private void btnBack_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            StockForm tobeOpen = new StockForm();
            tobeOpen.Show();
        }


    }
}
