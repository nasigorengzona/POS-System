﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;

namespace FinalProjectSE
{
    public partial class Form1 : Form
    {
        SqlConnection Server = new SqlConnection(DBConn.ConnectionString);

        public static int idAdmin;

        public Form1()
        {
            InitializeComponent();
        }

        public void btnOk_Click(object sender, EventArgs e)
        {
            
            Server.Open();
            SqlCommand cmd = new SqlCommand("Select Count(*) from Admin where usernameAdmin = '" + tbUsername.Text + "' and passAdmin = '" + tbPass.Text + "'  ", Server);
            int usernameAdmin = Convert.ToInt32(cmd.ExecuteScalar());
            cmd.Dispose();
            SqlCommand cmdIdAdmin = new SqlCommand("Select idAdmin from Admin where usernameAdmin = '" + tbUsername.Text + "'", Server);
            idAdmin = Convert.ToInt32(cmdIdAdmin.ExecuteScalar());
            cmdIdAdmin.Dispose();
            Server.Close();
            if(usernameAdmin == 1){
                this.Hide();
                Form2 tobeOpen = new Form2();
                tobeOpen.idAdminForm2 = idAdmin;
                //MessageBox.Show(idAdminForm2.ToString());
                tobeOpen.Show();  
            } 
            else {
                MessageBox.Show("Username or Password is wrong. Try Again !");
                tbPass.Text = "";
                tbUsername.Text = "";
            }
        }
    }
}
